@echo off
cd /d "%~dp0"
start "" pythonw.exe bot_detector.py
exit