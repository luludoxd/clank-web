import tkinter as tk
import os
import json
import re
import webbrowser
import urllib.request

from tkinter import ttk, messagebox
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from datetime import datetime, timezone
from urllib.parse import urlparse
from pathlib import Path


try:
    from PIL import Image, ImageTk
except Exception:
    Image = None
    ImageTk = None


# ============================================================
# SETTINGS
# ============================================================

# API key is entered through Settings and kept in memory only.
YOUTUBE_API_KEY = ""

# Minimum score required for a result to appear.
MIN_SCORE = 25

# Maximum account age included in analysis.
MAX_ANALYSIS_ACCOUNT_AGE_DAYS = 10

# Maximum possible score.
MAX_SCORE = 50

REPORT_GROUP_NAME = (
    "CLANk, Clanker Logging & Analysis Network"
)

PROFILE_IMAGE_FOLDER = (
    Path("reports") / "profile_images"
)

youtube = None


# ============================================================
# YOUTUBE API
# ============================================================

def youtube_api_available():
    return bool(YOUTUBE_API_KEY.strip())


def get_youtube_service():
    global youtube

    if not youtube_api_available():
        raise RuntimeError(
            "No YouTube API key configured.\n\n"
            "Go to Settings → YouTube API Key "
            "and enter an API key."
        )

    if youtube is None:
        youtube = build(
            "youtube",
            "v3",
            developerKey=YOUTUBE_API_KEY.strip()
        )

    return youtube


def youtube_error_message(error):
    """
    Converts common YouTube API errors into useful messages.
    """

    if isinstance(error, HttpError):
        status = getattr(
            error.resp,
            "status",
            None
        )

        error_text = str(error)

        if status == 403 and (
            "quotaExceeded" in error_text
            or "quota" in error_text.lower()
        ):
            return (
                "YouTube API quota exceeded.\n\n"
                "Google has temporarily stopped allowing "
                "requests from this API key because its "
                "daily quota has been used.\n\n"
                "The application is already configured to "
                "scan all available comment pages. There "
                "is no artificial comment limit in this "
                "version.\n\n"
                "You will need to wait for the API quota "
                "to reset or use another API project/key."
            )

        if status == 403:
            return (
                "YouTube rejected the API request (403).\n\n"
                "This can happen if the API is disabled, "
                "the API key restrictions are incorrect, "
                "or the requested resource is unavailable."
            )

        if status == 400:
            return (
                "YouTube rejected the request (400).\n\n"
                "The video may be unavailable or the URL "
                "may not refer to a valid video."
            )

        if status == 404:
            return (
                "YouTube could not find the requested video "
                "or resource."
            )

    return str(error)


# ============================================================
# URL / TEXT HELPERS
# ============================================================

def video_id_from_url(url):
    patterns = [
        r"(?:v=)([A-Za-z0-9_-]{11})",
        r"youtu\.be/([A-Za-z0-9_-]{11})",
        r"youtube\.com/shorts/([A-Za-z0-9_-]{11})"
    ]

    for pattern in patterns:
        match = re.search(
            pattern,
            url
        )

        if match:
            return match.group(1)

    return None


def account_age_days(created):
    if not created or created == "Unknown":
        return None

    try:
        date = datetime.fromisoformat(
            created.replace(
                "Z",
                "+00:00"
            )
        )

        now = datetime.now(
            timezone.utc
        )

        return (
            now - date
        ).days

    except Exception:
        return None


def find_domains(text):
    urls = re.findall(
        r"(?:https?://|www\.)[^\s]+",
        text,
        flags=re.IGNORECASE
    )

    domains = []

    for url in urls:
        url = url.rstrip(
            ".,!?;:)]}"
        )

        if not url.startswith("http"):
            url = "https://" + url

        try:
            domain = urlparse(
                url
            ).netloc.lower()

            if domain.startswith("www."):
                domain = domain[4:]

            if domain:
                domains.append(domain)

        except Exception:
            pass

    return domains


def find_youtube_references(text):
    references = set()

    channel_ids = re.findall(
        r"youtube\.com/channel/(UC[A-Za-z0-9_-]{20,})",
        text,
        flags=re.IGNORECASE
    )

    for channel_id in channel_ids:
        references.add(
            channel_id
        )

    handles = re.findall(
        r"(?:youtube\.com/)?@([A-Za-z0-9._-]{3,30})",
        text,
        flags=re.IGNORECASE
    )

    for handle in handles:
        references.add(
            "HANDLE:" + handle.lower()
        )

    custom_urls = re.findall(
        r"youtube\.com/(?:c|user)/([A-Za-z0-9._-]{3,100})",
        text,
        flags=re.IGNORECASE
    )

    for name in custom_urls:
        references.add(
            "NAME:" + name.lower()
        )

    return references


# ============================================================
# COMMENTS
# ============================================================

def get_comments(video_id, progress_callback=None):
    """
    Downloads ALL available top-level comments.

    There is intentionally NO artificial comment limit.

    YouTube returns comments in pages of up to 100. This
    function continues requesting pages until YouTube no
    longer supplies a nextPageToken.

    Note:
    YouTube API quota still applies. The program cannot
    bypass Google's quota system.
    """

    api = get_youtube_service()

    all_comments = []
    next_page = None
    page_number = 0

    while True:
        page_number += 1

        if progress_callback:
            progress_callback(
                f"Downloading comments... "
                f"{len(all_comments):,} collected"
            )

        request_kwargs = {
            "part": "snippet",
            "videoId": video_id,
            "maxResults": 100,
            "textFormat": "plainText"
        }

        if next_page:
            request_kwargs[
                "pageToken"
            ] = next_page

        try:
            result = (
                api.commentThreads()
                .list(**request_kwargs)
                .execute()
            )

        except HttpError:
            raise

        for item in result.get(
            "items",
            []
        ):
            try:
                snippet = (
                    item["snippet"]
                    ["topLevelComment"]
                    ["snippet"]
                )

            except KeyError:
                continue

            channel_id = (
                snippet
                .get(
                    "authorChannelId",
                    {}
                )
                .get(
                    "value"
                )
            )

            if not channel_id:
                continue

            all_comments.append({
                "channel_id": channel_id,
                "name": snippet.get(
                    "authorDisplayName",
                    "Unknown"
                ),
                "text": snippet.get(
                    "textDisplay",
                    ""
                ),
                "profile_image": snippet.get(
                    "authorProfileImageUrl",
                    ""
                )
            })

        next_page = result.get(
            "nextPageToken"
        )

        if not next_page:
            break

    if progress_callback:
        progress_callback(
            f"Finished downloading "
            f"{len(all_comments):,} comments"
        )

    return all_comments


def get_unique_channels(comments):
    channels = {}

    for comment in comments:
        channel_id = comment[
            "channel_id"
        ]

        if channel_id not in channels:
            channels[channel_id] = {
                "name": comment["name"],
                "channel_id": channel_id,
                "channel_url": (
                    "https://www.youtube.com/channel/"
                    + channel_id
                ),
                "profile_image": comment[
                    "profile_image"
                ],
                "comments": []
            }

        channels[channel_id][
            "comments"
        ].append(
            comment["text"]
        )

    return channels


# ============================================================
# CHANNEL INFORMATION
# ============================================================

def get_channel_information(
    channel_ids,
    progress_callback=None
):
    api = get_youtube_service()

    channels = {}

    for start in range(
        0,
        len(channel_ids),
        50
    ):
        batch = channel_ids[
            start:start + 50
        ]

        if progress_callback:
            progress_callback(
                f"Loading account information... "
                f"{min(start + 50, len(channel_ids)):,}/"
                f"{len(channel_ids):,}"
            )

        result = api.channels().list(
            part="snippet,statistics",
            id=",".join(batch)
        ).execute()

        for channel in result.get(
            "items",
            []
        ):
            snippet = channel.get(
                "snippet",
                {}
            )

            statistics = channel.get(
                "statistics",
                {}
            )

            channel_id = channel["id"]

            channels[channel_id] = {
                "name": snippet.get(
                    "title",
                    "Unknown"
                ),
                "description": snippet.get(
                    "description",
                    ""
                ),
                "created": snippet.get(
                    "publishedAt",
                    "Unknown"
                ),
                "videos": statistics.get(
                    "videoCount",
                    "Unknown"
                ),
                "subscribers": statistics.get(
                    "subscriberCount",
                    "Unknown"
                ),
                "channel_url": (
                    "https://www.youtube.com/channel/"
                    + channel_id
                )
            }

    return channels


# ============================================================
# NETWORK ANALYSIS
# ============================================================

def build_domain_connections(channels):
    domain_accounts = {}

    for channel_id, channel in channels.items():
        domains = set()

        for comment in channel[
            "comments"
        ]:
            domains.update(
                find_domains(comment)
            )

        for domain in domains:
            if domain not in domain_accounts:
                domain_accounts[domain] = set()

            domain_accounts[
                domain
            ].add(
                channel_id
            )

    return domain_accounts


def build_youtube_connections(
    channels,
    channel_infos
):
    connections = {}

    for channel_id, channel in channels.items():
        info = channel_infos.get(
            channel_id
        )

        if not info:
            continue

        references = set()

        references.update(
            find_youtube_references(
                info["description"]
            )
        )

        for comment in channel[
            "comments"
        ]:
            references.update(
                find_youtube_references(
                    comment
                )
            )

        connections[
            channel_id
        ] = references

    return connections


# ============================================================
# SCORING
# ============================================================

def calculate_score(
    channel_id,
    channel,
    channel_info,
    domain_accounts,
    youtube_connections,
    all_channel_ids
):
    """
    Maximum score = 50.

    The scoring uses the original 50-point scale.
    """

    score = 0
    reasons = []
    flags = []

    # --------------------------------------------------------
    # ACCOUNT AGE
    # --------------------------------------------------------

    age = account_age_days(
        channel_info["created"]
    )

    if age is not None:

        if age <= 3:
            score += 50

            reason = (
                f"Account is only {age} days old"
            )

            reasons.append(reason)
            flags.append("Very new account")

        elif age <= 7:
            score += 15

            reason = (
                f"Account is only {age} days old"
            )

            reasons.append(reason)
            flags.append("New account")

        elif age <= 30:
            score += 10

            reason = (
                f"Account is only {age} days old"
            )

            reasons.append(reason)
            flags.append("Recently created account")

    # --------------------------------------------------------
    # VIDEOS
    # --------------------------------------------------------

    try:
        videos = int(
            channel_info["videos"]
        )

        if videos == 0:
            score += 10

            reasons.append(
                "No public videos"
            )

            flags.append(
                "No public videos"
            )

        elif videos <= 2:
            score += 10

            reasons.append(
                f"Only {videos} public videos"
            )

            flags.append(
                "Very few public videos"
            )

    except Exception:
        pass

    # --------------------------------------------------------
    # CHANNEL DESCRIPTION LINKS
    # --------------------------------------------------------

    description_domains = find_domains(
        channel_info["description"]
    )

    if description_domains:
        score += 10

        reasons.append(
            "Links found in channel description"
        )

        flags.append(
            "Links in description"
        )

    # --------------------------------------------------------
    # COMMENT COUNT
    # --------------------------------------------------------

    comment_count = len(
        channel["comments"]
    )

    if comment_count >= 3:
        score += 5

        reasons.append(
            f"{comment_count} comments under this video"
        )

        flags.append(
            "Multiple comments"
        )

    # --------------------------------------------------------
    # LINKS IN COMMENTS
    # --------------------------------------------------------

    own_domains = set()

    for comment in channel[
        "comments"
    ]:
        own_domains.update(
            find_domains(comment)
        )

    if own_domains:
        score += 10

        reasons.append(
            "Links found in comments"
        )

        flags.append(
            "Links in comments"
        )

    # --------------------------------------------------------
    # SHARED DOMAINS
    # --------------------------------------------------------

    shared_domain_found = False

    for domain in own_domains:
        others = (
            domain_accounts.get(
                domain,
                set()
            )
            - {channel_id}
        )

        if others:
            score += 10

            reasons.append(
                f"Domain '{domain}' also used "
                "by other accounts"
            )

            flags.append(
                "Shared website/domain"
            )

            shared_domain_found = True
            break

    # --------------------------------------------------------
    # YOUTUBE REFERENCES
    # --------------------------------------------------------

    own_references = (
        youtube_connections.get(
            channel_id,
            set()
        )
    )

    if own_references:
        score += 10

        reasons.append(
            f"{len(own_references)} YouTube "
            "references found"
        )

        flags.append(
            "YouTube references"
        )

    # --------------------------------------------------------
    # DIRECT ACCOUNT CONNECTIONS
    # --------------------------------------------------------

    connected_accounts = []

    for reference in own_references:

        if (
            reference.startswith("UC")
            and reference in all_channel_ids
            and reference != channel_id
        ):
            connected_accounts.append(
                reference
            )

    if connected_accounts:
        score += 15

        reasons.append(
            f"{len(connected_accounts)} directly "
            "connected matching accounts"
        )

        flags.append(
            "Connected accounts"
        )

    # --------------------------------------------------------
    # CAP SCORE
    # --------------------------------------------------------

    score = min(
        score,
        MAX_SCORE
    )

    # --------------------------------------------------------
    # CLASSIFICATION
    # --------------------------------------------------------

    if score >= 80:
        classification = (
            "HIGHLY SUSPICIOUS"
        )

    elif score >= 60:
        classification = (
            "SUSPICIOUS"
        )

    else:
        classification = (
            "REVIEW"
        )

    # Remove duplicate flags.
    flags = list(
        dict.fromkeys(flags)
    )

    return (
        score,
        classification,
        reasons,
        connected_accounts,
        flags
    )


# ============================================================
# PROFILE IMAGE
# ============================================================

def save_profile_image(
    url,
    channel_id
):
    if not url:
        return None

    try:
        PROFILE_IMAGE_FOLDER.mkdir(
            parents=True,
            exist_ok=True
        )

        file = (
            PROFILE_IMAGE_FOLDER
            / f"{channel_id}.jpg"
        )

        request = urllib.request.Request(
            url,
            headers={
                "User-Agent":
                    "Mozilla/5.0"
            }
        )

        with urllib.request.urlopen(
            request,
            timeout=15
        ) as response:
            data = response.read()

        with open(
            file,
            "wb"
        ) as f:
            f.write(data)

        return str(file)

    except Exception as error:
        print(
            "Profile image could not be saved:",
            error
        )

        return None


# ============================================================
# REPORT GENERATION
# ============================================================

def create_report_text(
    result,
    profile_image=False
):
    reasons = []

    reasons.append(
        "Spam bot promoting and spreading adult-rated websites"
    )

    has_links = False

    if find_domains(
        result.get(
            "comment",
            ""
        )
    ):
        has_links = True

    for reason in result.get(
        "reasons",
        []
    ):
        if (
            "link" in reason.lower()
            or "domain" in reason.lower()
            or "website" in reason.lower()
        ):
            has_links = True
            break

    if has_links:
        reasons.append(
            "Suspicious links"
        )

    if profile_image:
        reasons.append(
            "Sexual profile picture"
        )

    unique_reasons = []

    for reason in reasons:
        if reason not in unique_reasons:
            unique_reasons.append(
                reason
            )

    reason_text = "\n".join(
        "- " + reason
        for reason in unique_reasons
    )

    return f"""
REPORT – PREPARED BY: {REPORT_GROUP_NAME}

Reason for report:

Spam bot promoting and spreading adult-rated websites.

Observed reasons:
{reason_text}
""".strip()


# ============================================================
# GUI
# ============================================================

class BotDetectorGUI:

    def __init__(
        self,
        root
    ):
        self.root = root

        self.root.title(
            "YouTube Bot Detector"
        )

        self.root.geometry(
            "1500x900"
        )

        self.root.minsize(
            1100,
            700
        )

        self.results = []
        self.analysis_running = False

        self.setup_colors()
        self.setup_style()
        self.create_gui()

    # ========================================================
    # COLORS
    # ========================================================

    def setup_colors(self):
        self.bg = "#0b1120"
        self.sidebar = "#111827"
        self.panel = "#172033"
        self.panel2 = "#1f2a3d"

        self.border = "#263449"

        self.text = "#f8fafc"
        self.subtext = "#94a3b8"

        self.accent = "#38bdf8"
        self.accent_dark = "#0284c7"

        self.green = "#22c55e"
        self.yellow = "#eab308"
        self.orange = "#f97316"
        self.red = "#ef4444"

    # ========================================================
    # STYLE
    # ========================================================

    def setup_style(self):
        style = ttk.Style()

        try:
            style.theme_use(
                "clam"
            )
        except Exception:
            pass

        style.configure(
            "Treeview",
            background=self.panel,
            foreground=self.text,
            fieldbackground=self.panel,
            borderwidth=0,
            relief="flat",
            rowheight=42,
            font=(
                "Segoe UI",
                9
            )
        )

        style.configure(
            "Treeview.Heading",
            background=self.panel2,
            foreground=self.subtext,
            borderwidth=0,
            relief="flat",
            font=(
                "Segoe UI",
                9,
                "bold"
            )
        )

        style.map(
            "Treeview",
            background=[
                (
                    "selected",
                    "#334155"
                )
            ],
            foreground=[
                (
                    "selected",
                    "#ffffff"
                )
            ]
        )

        style.configure(
            "TNotebook",
            background=self.bg,
            borderwidth=0
        )

        style.configure(
            "TNotebook.Tab",
            background=self.panel,
            foreground=self.subtext,
            padding=[
                18,
                9
            ],
            font=(
                "Segoe UI",
                9,
                "bold"
            )
        )

        style.map(
            "TNotebook.Tab",
            background=[
                (
                    "selected",
                    self.accent_dark
                )
            ],
            foreground=[
                (
                    "selected",
                    "#ffffff"
                )
            ]
        )

    # ========================================================
    # GUI CREATION
    # ========================================================

    def create_gui(self):

        self.root.configure(
            bg=self.bg
        )

        self.create_menu()

        # ----------------------------------------------------
        # Main application shell
        # ----------------------------------------------------

        shell = tk.Frame(
            self.root,
            bg=self.bg
        )

        shell.pack(
            fill="both",
            expand=True
        )

        # ----------------------------------------------------
        # Sidebar
        # ----------------------------------------------------

        self.sidebar_frame = tk.Frame(
            shell,
            bg=self.sidebar,
            width=235
        )

        self.sidebar_frame.pack(
            side="left",
            fill="y"
        )

        self.sidebar_frame.pack_propagate(
            False
        )

        self.create_sidebar()

        # ----------------------------------------------------
        # Content
        # ----------------------------------------------------

        self.content_frame = tk.Frame(
            shell,
            bg=self.bg
        )

        self.content_frame.pack(
            side="left",
            fill="both",
            expand=True
        )

        self.notebook = ttk.Notebook(
            self.content_frame
        )

        self.notebook.pack(
            fill="both",
            expand=True,
            padx=12,
            pady=12
        )

        self.analysis_tab = tk.Frame(
            self.notebook,
            bg=self.bg
        )

        self.library_tab = tk.Frame(
            self.notebook,
            bg=self.bg
        )

        self.notebook.add(
            self.analysis_tab,
            text="  🔎  Analysis  "
        )

        self.notebook.add(
            self.library_tab,
            text="  📚  Library  "
        )

        self.analysis_parent = (
            self.analysis_tab
        )

        self.create_analysis_tab()
        self.create_library_tab()

        self.update_api_status()

    # ========================================================
    # SIDEBAR
    # ========================================================

    def create_sidebar(self):

        logo = tk.Frame(
            self.sidebar_frame,
            bg=self.sidebar
        )

        logo.pack(
            fill="x",
            padx=20,
            pady=(28, 20)
        )

        tk.Label(
            logo,
            text="CLANk",
            bg=self.sidebar,
            fg=self.accent,
            font=(
                "Segoe UI",
                24,
                "bold"
            )
        ).pack(
            anchor="w"
        )

        tk.Label(
            logo,
            text="YouTube Bot Detector",
            bg=self.sidebar,
            fg=self.text,
            font=(
                "Segoe UI",
                10,
                "bold"
            )
        ).pack(
            anchor="w"
        )

        tk.Label(
            logo,
            text="Logging & Analysis Network",
            bg=self.sidebar,
            fg=self.subtext,
            font=(
                "Segoe UI",
                8
            )
        ).pack(
            anchor="w",
            pady=(2, 0)
        )

        # ----------------------------------------------------
        # Navigation
        # ----------------------------------------------------

        tk.Label(
            self.sidebar_frame,
            text="WORKSPACE",
            bg=self.sidebar,
            fg="#64748b",
            font=(
                "Segoe UI",
                8,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=20,
            pady=(10, 8)
        )

        self.sidebar_button(
            "🔎  Analysis",
            lambda: self.notebook.select(
                self.analysis_tab
            )
        )

        self.sidebar_button(
            "📚  Account Library",
            lambda: self.notebook.select(
                self.library_tab
            )
        )

        tk.Label(
            self.sidebar_frame,
            text="SYSTEM",
            bg=self.sidebar,
            fg="#64748b",
            font=(
                "Segoe UI",
                8,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=20,
            pady=(28, 8)
        )

        self.sidebar_button(
            "🔑  API Key",
            self.enter_youtube_api_key
        )

        self.sidebar_button(
            "ℹ️  API Status",
            self.show_api_status
        )

        # ----------------------------------------------------
        # Sidebar status
        # ----------------------------------------------------

        status_frame = tk.Frame(
            self.sidebar_frame,
            bg=self.panel,
            highlightbackground=self.border,
            highlightthickness=1
        )

        status_frame.pack(
            side="bottom",
            fill="x",
            padx=15,
            pady=15
        )

        tk.Label(
            status_frame,
            text="API STATUS",
            bg=self.panel,
            fg=self.subtext,
            font=(
                "Segoe UI",
                8,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=12,
            pady=(10, 2)
        )

        self.sidebar_api_status = tk.Label(
            status_frame,
            text="● Not configured",
            bg=self.panel,
            fg="#fca5a5",
            font=(
                "Segoe UI",
                9,
                "bold"
            )
        )

        self.sidebar_api_status.pack(
            anchor="w",
            padx=12,
            pady=(0, 10)
        )

    def sidebar_button(
        self,
        text,
        command
    ):
        button = tk.Button(
            self.sidebar_frame,
            text=text,
            command=command,
            bg=self.sidebar,
            fg=self.subtext,
            activebackground=self.panel2,
            activeforeground=self.text,
            relief="flat",
            borderwidth=0,
            anchor="w",
            cursor="hand2",
            font=(
                "Segoe UI",
                10
            )
        )

        button.pack(
            fill="x",
            padx=10,
            pady=2,
            ipady=8
        )

        return button

    # ========================================================
    # ANALYSIS TAB
    # ========================================================

    def create_analysis_tab(self):

        # ----------------------------------------------------
        # Header
        # ----------------------------------------------------

        header = tk.Frame(
            self.analysis_parent,
            bg=self.bg
        )

        header.pack(
            fill="x",
            padx=25,
            pady=(20, 12)
        )

        title_frame = tk.Frame(
            header,
            bg=self.bg
        )

        title_frame.pack(
            side="left"
        )

        tk.Label(
            title_frame,
            text="YouTube Bot Analysis",
            bg=self.bg,
            fg=self.text,
            font=(
                "Segoe UI",
                23,
                "bold"
            )
        ).pack(
            anchor="w"
        )

        tk.Label(
            title_frame,
            text=(
                "Analyze comments, accounts and suspicious "
                "behavior across a YouTube video."
            ),
            bg=self.bg,
            fg=self.subtext,
            font=(
                "Segoe UI",
                10
            )
        ).pack(
            anchor="w",
            pady=(3, 0)
        )

        self.status_label = tk.Label(
            header,
            text="READY",
            bg="#064e3b",
            fg="#86efac",
            padx=14,
            pady=7,
            font=(
                "Segoe UI",
                9,
                "bold"
            )
        )

        self.status_label.pack(
            side="right",
            anchor="n"
        )

        # ----------------------------------------------------
        # URL card
        # ----------------------------------------------------

        url_card = tk.Frame(
            self.analysis_parent,
            bg=self.panel,
            highlightbackground=self.border,
            highlightthickness=1
        )

        url_card.pack(
            fill="x",
            padx=25,
            pady=7
        )

        tk.Label(
            url_card,
            text="VIDEO SOURCE",
            bg=self.panel,
            fg=self.subtext,
            font=(
                "Segoe UI",
                8,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=18,
            pady=(14, 4)
        )

        entry_row = tk.Frame(
            url_card,
            bg=self.panel
        )

        entry_row.pack(
            fill="x",
            padx=18,
            pady=(0, 14)
        )

        self.url_entry = tk.Entry(
            entry_row,
            bg="#0b1220",
            fg=self.text,
            insertbackground=self.text,
            relief="flat",
            font=(
                "Segoe UI",
                11
            )
        )

        self.url_entry.pack(
            side="left",
            fill="x",
            expand=True,
            ipady=10
        )

        self.analyse_button = tk.Button(
            entry_row,
            text="▶  START ANALYSIS",
            bg=self.accent_dark,
            fg="#ffffff",
            activebackground=self.accent,
            activeforeground="#ffffff",
            relief="flat",
            cursor="hand2",
            font=(
                "Segoe UI",
                9,
                "bold"
            ),
            command=self.start_analysis
        )

        self.analyse_button.pack(
            side="right",
            padx=(10, 0),
            ipadx=15,
            ipady=9
        )

        # ----------------------------------------------------
        # Information strip
        # ----------------------------------------------------

        info = tk.Frame(
            self.analysis_parent,
            bg="#082f49",
            highlightbackground="#0c4a6e",
            highlightthickness=1
        )

        info.pack(
            fill="x",
            padx=25,
            pady=7
        )

        tk.Label(
            info,
            text="●",
            bg="#082f49",
            fg=self.accent,
            font=(
                "Segoe UI",
                12,
                "bold"
            )
        ).pack(
            side="left",
            padx=(14, 7)
        )

        tk.Label(
            info,
            text=(
                "Unlimited comment pagination enabled — "
                "the analyzer will continue until all "
                "available top-level comments have been read."
            ),
            bg="#082f49",
            fg="#bae6fd",
            font=(
                "Segoe UI",
                9
            )
        ).pack(
            side="left",
            pady=9
        )

        # ----------------------------------------------------
        # Statistics
        # ----------------------------------------------------

        stats = tk.Frame(
            self.analysis_parent,
            bg=self.bg
        )

        stats.pack(
            fill="x",
            padx=20,
            pady=7
        )

        self.stat_comments = self.stat_box(
            stats,
            "COMMENTS SCANNED",
            "0"
        )

        self.stat_accounts = self.stat_box(
            stats,
            "ACCOUNTS FOUND",
            "0"
        )

        self.stat_hits = self.stat_box(
            stats,
            "FLAGGED RESULTS",
            "0"
        )

        self.stat_max = self.stat_box(
            stats,
            "MAX SCORE",
            "50"
        )

        # ----------------------------------------------------
        # Results header
        # ----------------------------------------------------

        result_header = tk.Frame(
            self.analysis_parent,
            bg=self.bg
        )

        result_header.pack(
            fill="x",
            padx=25,
            pady=(13, 6)
        )

        tk.Label(
            result_header,
            text="Analysis Results",
            bg=self.bg,
            fg=self.text,
            font=(
                "Segoe UI",
                14,
                "bold"
            )
        ).pack(
            side="left"
        )

        tk.Label(
            result_header,
            text=(
                f"Showing scores above {MIN_SCORE} / "
                f"{MAX_SCORE}"
            ),
            bg=self.bg,
            fg=self.subtext,
            font=(
                "Segoe UI",
                9
            )
        ).pack(
            side="right"
        )

        # ----------------------------------------------------
        # Table
        # ----------------------------------------------------

        table_frame = tk.Frame(
            self.analysis_parent,
            bg=self.bg
        )

        table_frame.pack(
            fill="both",
            expand=True,
            padx=25,
            pady=5
        )

        columns = (
            "score",
            "account",
            "comment",
            "age",
            "flags",
            "action"
        )

        self.tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings"
        )

        headings = {
            "score": "SCORE / 50",
            "account": "ACCOUNT",
            "comment": "COMMENT",
            "age": "AGE",
            "flags": "FLAGS",
            "action": "ACTION"
        }

        for column, text in headings.items():
            self.tree.heading(
                column,
                text=text
            )

        self.tree.column(
            "score",
            width=90,
            anchor="center"
        )

        self.tree.column(
            "account",
            width=190
        )

        self.tree.column(
            "comment",
            width=380
        )

        self.tree.column(
            "age",
            width=90,
            anchor="center"
        )

        self.tree.column(
            "flags",
            width=280
        )

        self.tree.column(
            "action",
            width=160,
            anchor="center"
        )

        scrollbar = ttk.Scrollbar(
            table_frame,
            orient="vertical",
            command=self.tree.yview
        )

        self.tree.configure(
            yscrollcommand=scrollbar.set
        )

        self.tree.pack(
            side="left",
            fill="both",
            expand=True
        )

        scrollbar.pack(
            side="right",
            fill="y"
        )

        self.tree.bind(
            "<Double-1>",
            self.open_channel
        )

        self.tree.bind(
            "<Button-1>",
            self.result_action_click
        )

        self.tree.tag_configure(
            "red",
            foreground="#fca5a5"
        )

        self.tree.tag_configure(
            "orange",
            foreground="#fdba74"
        )

        self.tree.tag_configure(
            "yellow",
            foreground="#fde047"
        )

        # ----------------------------------------------------
        # Bottom toolbar
        # ----------------------------------------------------

        bottom = tk.Frame(
            self.analysis_parent,
            bg=self.bg
        )

        bottom.pack(
            fill="x",
            padx=25,
            pady=(6, 18)
        )

        self.app_button(
            bottom,
            "🚩  Prepare Report",
            self.prepare_report,
            "#7f1d1d",
            "#fee2e2"
        ).pack(
            side="left",
            padx=(0, 7)
        )

        self.app_button(
            bottom,
            "🖼  Profile Report",
            self.prepare_profile_image_report,
            "#713f12",
            "#fef3c7"
        ).pack(
            side="left",
            padx=7
        )

        self.app_button(
            bottom,
            "🌐  Open Channel",
            self.open_channel,
            "#164e63",
            "#cffafe"
        ).pack(
            side="left",
            padx=7
        )

        self.app_button(
            bottom,
            "📋  Copy Flags",
            self.copy_flags,
            "#334155",
            self.text
        ).pack(
            side="left",
            padx=7
        )

    # ========================================================
    # APP BUTTON
    # ========================================================

    def app_button(
        self,
        parent,
        text,
        command,
        bg,
        fg
    ):
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=bg,
            fg=fg,
            activebackground=self.panel2,
            activeforeground=self.text,
            relief="flat",
            cursor="hand2",
            font=(
                "Segoe UI",
                9,
                "bold"
            ),
            padx=10,
            pady=7
        )

    # ========================================================
    # STAT BOX
    # ========================================================

    def stat_box(
        self,
        parent,
        title,
        value
    ):
        frame = tk.Frame(
            parent,
            bg=self.panel,
            highlightbackground=self.border,
            highlightthickness=1
        )

        frame.pack(
            side="left",
            fill="x",
            expand=True,
            padx=5
        )

        tk.Label(
            frame,
            text=title,
            bg=self.panel,
            fg=self.subtext,
            font=(
                "Segoe UI",
                8,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=14,
            pady=(10, 1)
        )

        value_label = tk.Label(
            frame,
            text=value,
            bg=self.panel,
            fg=self.text,
            font=(
                "Segoe UI",
                18,
                "bold"
            )
        )

        value_label.pack(
            anchor="w",
            padx=14,
            pady=(0, 9)
        )

        return value_label

    # ========================================================
    # MENU
    # ========================================================

    def create_menu(self):

        menubar = tk.Menu(
            self.root
        )

        settings = tk.Menu(
            menubar,
            tearoff=0
        )

        settings.add_command(
            label="🔑 YouTube API Key",
            command=self.enter_youtube_api_key
        )

        settings.add_separator()

        settings.add_command(
            label="ℹ️ API Status",
            command=self.show_api_status
        )

        menubar.add_cascade(
            label="⚙ Settings",
            menu=settings
        )

        help_menu = tk.Menu(
            menubar,
            tearoff=0
        )

        help_menu.add_command(
            label="About",
            command=self.show_about
        )

        menubar.add_cascade(
            label="❓ Help",
            menu=help_menu
        )

        self.root.config(
            menu=menubar
        )

    # ========================================================
    # API KEY
    # ========================================================

    def enter_youtube_api_key(self):

        global YOUTUBE_API_KEY
        global youtube

        dialog = tk.Toplevel(
            self.root
        )

        dialog.title(
            "YouTube API Key"
        )

        dialog.geometry(
            "650x280"
        )

        dialog.resizable(
            False,
            False
        )

        dialog.configure(
            bg=self.bg
        )

        dialog.transient(
            self.root
        )

        dialog.grab_set()

        tk.Label(
            dialog,
            text="🔑  YouTube API Key",
            bg=self.bg,
            fg=self.text,
            font=(
                "Segoe UI",
                17,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=28,
            pady=(25, 5)
        )

        tk.Label(
            dialog,
            text=(
                "The API key is kept only in memory for "
                "this session."
            ),
            bg=self.bg,
            fg=self.subtext,
            justify="left",
            font=(
                "Segoe UI",
                9
            )
        ).pack(
            anchor="w",
            padx=28,
            pady=(0, 15)
        )

        entry = tk.Entry(
            dialog,
            bg="#0b1220",
            fg=self.text,
            insertbackground=self.text,
            relief="flat",
            show="•",
            font=(
                "Segoe UI",
                11
            )
        )

        entry.pack(
            fill="x",
            padx=28,
            ipady=10
        )

        if YOUTUBE_API_KEY:
            entry.insert(
                0,
                YOUTUBE_API_KEY
            )

        entry.focus_set()

        button_frame = tk.Frame(
            dialog,
            bg=self.bg
        )

        button_frame.pack(
            fill="x",
            padx=28,
            pady=22
        )

        def save():

            global YOUTUBE_API_KEY
            global youtube

            key = entry.get().strip()

            if not key:
                messagebox.showwarning(
                    "No API Key",
                    "Please enter a YouTube API key.",
                    parent=dialog
                )

                return

            YOUTUBE_API_KEY = key

            youtube = None

            self.update_api_status()

            dialog.destroy()

            messagebox.showinfo(
                "API Key Saved",
                "The YouTube API key is active for this session.",
                parent=self.root
            )

        tk.Button(
            button_frame,
            text="Cancel",
            command=dialog.destroy,
            bg=self.panel2,
            fg=self.text,
            activebackground=self.border,
            relief="flat",
            padx=15,
            pady=7
        ).pack(
            side="right",
            padx=5
        )

        tk.Button(
            button_frame,
            text="Save API Key",
            command=save,
            bg=self.accent_dark,
            fg="#ffffff",
            activebackground=self.accent,
            relief="flat",
            padx=15,
            pady=7
        ).pack(
            side="right",
            padx=5
        )

        dialog.bind(
            "<Return>",
            lambda event: save()
        )

        dialog.bind(
            "<Escape>",
            lambda event: dialog.destroy()
        )

    def update_api_status(self):

        if youtube_api_available():

            if hasattr(self, "sidebar_api_status"):
                self.sidebar_api_status.config(
                    text="● Connected",
                    fg="#86efac"
                )

        else:

            if hasattr(self, "sidebar_api_status"):
                self.sidebar_api_status.config(
                    text="● Not configured",
                    fg="#fca5a5"
                )
    def show_api_status(self):

        if youtube_api_available():

            messagebox.showinfo(
                "YouTube API",
                (
                    "🟢 API key configured.\n\n"
                    "The key is stored only in memory "
                    "for this program session."
                )
            )

        else:

            messagebox.showwarning(
                "YouTube API",
                (
                    "🔴 No API key configured.\n\n"
                    "Go to Settings → YouTube API Key."
                )
            )

    def show_about(self):

        messagebox.showinfo(
            "About",
            (
                "YouTube Bot Detector\n\n"
                "Comment and account analysis tool.\n\n"
                f"Report organization:\n"
                f"{REPORT_GROUP_NAME}\n\n"
                f"Maximum score: {MAX_SCORE}\n"
                "Comment pagination: Unlimited"
            )
        )

    # ========================================================
    # STATUS
    # ========================================================

    def set_status(
        self,
        text,
        color=None,
        fg=None
    ):
        if color is None:
            color = "#064e3b"

        if fg is None:
            fg = "#86efac"

        self.status_label.config(
            text=text,
            bg=color,
            fg=fg
        )

        self.root.update_idletasks()

    # ========================================================
    # START ANALYSIS
    # ========================================================

    def start_analysis(self):

        if self.analysis_running:
            return

        if not youtube_api_available():

            result = messagebox.askyesno(
                "API Key Missing",
                (
                    "No YouTube API key has been configured.\n\n"
                    "Open the API key settings now?"
                )
            )

            if result:
                self.enter_youtube_api_key()

            return

        url = self.url_entry.get().strip()

        if not url:

            messagebox.showwarning(
                "No URL",
                "Enter a YouTube video or Short URL."
            )

            return

        video_id = video_id_from_url(
            url
        )

        if not video_id:

            messagebox.showerror(
                "Invalid YouTube URL",
                "No valid YouTube video ID was found."
            )

            return

        self.analysis_running = True

        self.analyse_button.config(
            state="disabled",
            text="⏳  ANALYZING..."
        )

        self.set_status(
            "SCANNING",
            "#713f12",
            "#fde68a"
        )

        try:

            # ------------------------------------------------
            # Download ALL comments
            # ------------------------------------------------

            comments = get_comments(
                video_id,
                progress_callback=lambda text:
                    self.set_status(
                        text,
                        "#082f49",
                        "#bae6fd"
                    )
            )

            self.stat_comments.config(
                text=f"{len(comments):,}"
            )

            # ------------------------------------------------
            # Unique accounts
            # ------------------------------------------------

            self.set_status(
                "BUILDING ACCOUNT LIST",
                "#082f49",
                "#bae6fd"
            )

            channels = get_unique_channels(
                comments
            )

            channel_ids = [
                cid
                for cid in channels.keys()
                if cid not in
                self.get_ignored_channel_ids()
            ]

            channels = {
                cid: channels[cid]
                for cid in channel_ids
            }

            self.stat_accounts.config(
                text=f"{len(channel_ids):,}"
            )

            # ------------------------------------------------
            # Channel information
            # ------------------------------------------------

            channel_infos = (
                get_channel_information(
                    channel_ids,
                    progress_callback=lambda text:
                        self.set_status(
                            text,
                            "#082f49",
                            "#bae6fd"
                        )
                )
            )

            # ------------------------------------------------
            # Network analysis
            # ------------------------------------------------

            self.set_status(
                "ANALYZING FLAGS",
                "#082f49",
                "#bae6fd"
            )

            domain_accounts = (
                build_domain_connections(
                    channels
                )
            )

            youtube_connections = (
                build_youtube_connections(
                    channels,
                    channel_infos
                )
            )

            results = []

            for channel_id in channel_ids:

                channel = channels[
                    channel_id
                ]

                info = channel_infos.get(
                    channel_id
                )

                if not info:
                    continue

                age = account_age_days(
                    info["created"]
                )

                if age is None:
                    continue

                # Only analyze accounts up to the configured age.
                if age > MAX_ANALYSIS_ACCOUNT_AGE_DAYS:
                    continue

                (
                    score,
                    classification,
                    reasons,
                    connected,
                    flags
                ) = calculate_score(
                    channel_id,
                    channel,
                    info,
                    domain_accounts,
                    youtube_connections,
                    channel_ids
                )

                if score <= MIN_SCORE:
                    continue

                if age == 1:
                    age_text = "1 day"

                else:
                    age_text = (
                        f"{age} days"
                    )

                for comment in channel[
                    "comments"
                ]:

                    results.append({
                        "score": score,
                        "classification":
                            classification,
                        "name":
                            info["name"],
                        "channel_id":
                            channel_id,
                        "channel_url":
                            info["channel_url"],
                        "comment":
                            comment,
                        "age":
                            age_text,
                        "connections":
                            len(connected),
                        "flags":
                            flags,
                        "reasons":
                            reasons,
                        "profile_image":
                            channel[
                                "profile_image"
                            ]
                    })

            results.sort(
                key=lambda x:
                    x["score"],
                reverse=True
            )

            self.results = results

            self.display_results(
                comments,
                len(channel_ids)
            )

            self.set_status(
                "ANALYSIS COMPLETE",
                "#064e3b",
                "#86efac"
            )

        except Exception as error:

            error_text = youtube_error_message(
                error
            )

            self.set_status(
                "ERROR",
                "#7f1d1d",
                "#fca5a5"
            )

            messagebox.showerror(
                "Analysis Error",
                error_text
            )

        finally:

            self.analysis_running = False

            self.analyse_button.config(
                state="normal",
                text="▶  START ANALYSIS"
            )

    # ========================================================
    # DISPLAY RESULTS
    # ========================================================

    def display_results(
        self,
        comments,
        account_count
    ):

        for item in self.tree.get_children():
            self.tree.delete(
                item
            )

        self.stat_comments.config(
            text=f"{len(comments):,}"
        )

        self.stat_accounts.config(
            text=f"{account_count:,}"
        )

        self.stat_hits.config(
            text=f"{len(self.results):,}"
        )

        for result in self.results:

            tag = self.score_tag(
                result["score"]
            )

            flags_text = ", ".join(
                result.get(
                    "flags",
                    []
                )
            )

            self.tree.insert(
                "",
                "end",
                values=(
                    f"{result['score']} / {MAX_SCORE}",
                    result["name"],
                    result["comment"],
                    result["age"],
                    flags_text if flags_text else "-",
                    "+ Add to Library"
                ),
                tags=(tag,)
            )

    def score_tag(
        self,
        score
    ):

        if score >= 40:
            return "red"

        if score >= 30:
            return "orange"

        return "yellow"

    # ========================================================
    # CURRENT RESULT
    # ========================================================

    def get_current_result(self):

        selection = self.tree.selection()

        if not selection:
            return None

        index = self.tree.index(
            selection[0]
        )

        if index >= len(self.results):
            return None

        return self.results[
            index
        ]

    # ========================================================
    # COPY FLAGS
    # ========================================================

    def copy_flags(self):

        result = self.get_current_result()

        if not result:

            messagebox.showinfo(
                "Selection",
                "Select a result first."
            )

            return

        flags = result.get(
            "flags",
            []
        )

        if not flags:
            text = "No specific flags recorded."

        else:
            text = "\n".join(
                "- " + flag
                for flag in flags
            )

        self.root.clipboard_clear()

        self.root.clipboard_append(
            text
        )

        self.root.update()

        messagebox.showinfo(
            "Flags Copied",
            "The account flags have been copied to your clipboard."
        )

    # ========================================================
    # OPEN CHANNEL
    # ========================================================

    def open_channel(
        self,
        event=None
    ):

        result = self.get_current_result()

        if not result:

            if event is None:

                messagebox.showinfo(
                    "Selection",
                    "Please select a result first."
                )

            return

        report = create_report_text(
            result,
            profile_image=False
        )

        self.root.clipboard_clear()

        self.root.clipboard_append(
            report
        )

        self.root.update()

        webbrowser.open(
            result["channel_url"]
        )

        if event is None:

            messagebox.showinfo(
                "Channel Opened",
                (
                    "The channel has been opened.\n\n"
                    "The prepared report has been copied "
                    "to your clipboard."
                )
            )

    # ========================================================
    # REPORT
    # ========================================================

    def prepare_report(self):

        result = self.get_current_result()

        if not result:

            messagebox.showinfo(
                "Selection",
                "Please select a result first."
            )

            return

        text = create_report_text(
            result,
            profile_image=False
        )

        self.root.clipboard_clear()

        self.root.clipboard_append(
            text
        )

        self.root.update()

        webbrowser.open(
            result["channel_url"]
        )

        messagebox.showinfo(
            "Report Prepared",
            (
                "The channel has been opened.\n\n"
                "The prepared report has been copied "
                "to your clipboard.\n\n"
                "Please personally review the account "
                "before submitting a report."
            )
        )

    def prepare_profile_image_report(self):

        result = self.get_current_result()

        if not result:

            messagebox.showinfo(
                "Selection",
                "Please select a result first."
            )

            return

        file = save_profile_image(
            result["profile_image"],
            result["channel_id"]
        )

        text = create_report_text(
            result,
            profile_image=True
        )

        self.root.clipboard_clear()

        self.root.clipboard_append(
            text
        )

        self.root.update()

        webbrowser.open(
            result["channel_url"]
        )

        if file:

            image_info = (
                f"\n\nProfile image saved to:\n{file}"
            )

        else:

            image_info = (
                "\n\nThe profile image could not "
                "be saved locally."
            )

        messagebox.showinfo(
            "Profile Report Prepared",
            (
                "The channel has been opened.\n\n"
                "The prepared report has been copied "
                "to your clipboard."
                + image_info
                + "\n\nPlease personally review the "
                "profile image before submitting a report."
            )
        )

    # ========================================================
    # LIBRARY FILES
    # ========================================================

    def _library_urls(self):

        path = Path(
            "channels.txt"
        )

        path.touch(
            exist_ok=True
        )

        try:

            return list(
                dict.fromkeys(
                    x.strip()
                    for x in path.read_text(
                        encoding="utf-8"
                    ).splitlines()
                    if (
                        x.strip()
                        and not x.strip().startswith("#")
                    )
                )
            )

        except Exception:

            return []

    def _library_data(self):

        path = Path(
            "channels_data.json"
        )

        if not path.exists():
            return {}

        try:

            data = json.loads(
                path.read_text(
                    encoding="utf-8"
                )
            )

            return (
                data
                if isinstance(
                    data,
                    dict
                )
                else {}
            )

        except Exception:

            return {}

    def _save_library_data(
        self,
        data
    ):

        Path(
            "channels_data.json"
        ).write_text(
            json.dumps(
                data,
                ensure_ascii=False,
                indent=2
            ),
            encoding="utf-8"
        )

    def get_ignored_channel_ids(self):

        data = self._library_data()

        ignored = set()

        for key, record in data.items():

            if (
                isinstance(
                    record,
                    dict
                )
                and record.get(
                    "channel_id"
                )
            ):

                ignored.add(
                    record["channel_id"]
                )

            elif str(key).startswith(
                "UC"
            ):

                ignored.add(
                    key
                )

        for url in self._library_urls():

            match = re.search(
                r"youtube\.com/channel/(UC[A-Za-z0-9_-]+)",
                url,
                re.I
            )

            if match:

                ignored.add(
                    match.group(1)
                )

        return ignored

    # ========================================================
    # ADD TO LIBRARY
    # ========================================================

    def add_to_library(
        self,
        result
    ):

        channel_id = result.get(
            "channel_id"
        )

        url = result.get(
            "channel_url"
        )

        if not channel_id or not url:
            return

        urls = self._library_urls()

        if url not in urls:
            urls.append(
                url
            )

        Path(
            "channels.txt"
        ).write_text(
            "\n".join(urls) + "\n",
            encoding="utf-8"
        )

        data = self._library_data()

        data[channel_id] = {
            "channel_id":
                channel_id,
            "url":
                url,
            "name":
                result.get(
                    "name",
                    "Unknown"
                ),
            "score":
                result.get(
                    "score"
                ),
            "flags":
                result.get(
                    "flags",
                    []
                ),
            "added":
                datetime.now(
                    timezone.utc
                ).isoformat()
        }

        self._save_library_data(
            data
        )

        self.results = [
            x
            for x in self.results
            if x.get(
                "channel_id"
            ) != channel_id
        ]

        self.display_results(
            [],
            0
        )

        self.update_library()

        self.set_status(
            "ACCOUNT ADDED TO LIBRARY",
            "#064e3b",
            "#86efac"
        )

    # ========================================================
    # RESULT ACTION
    # ========================================================

    def result_action_click(
        self,
        event
    ):

        if self.tree.identify(
            "region",
            event.x,
            event.y
        ) != "cell":

            return

        if self.tree.identify_column(
            event.x
        ) != "#6":

            return

        row = self.tree.identify_row(
            event.y
        )

        if not row:
            return

        try:

            result = self.results[
                self.tree.index(row)
            ]

        except (
            IndexError,
            ValueError
        ):

            return

        self.add_to_library(
            result
        )

        return "break"

    # ========================================================
    # LIBRARY
    # ========================================================

    def library_stat_box(
        self,
        parent,
        title,
        value
    ):

        frame = tk.Frame(
            parent,
            bg=self.panel,
            highlightbackground=self.border,
            highlightthickness=1
        )

        frame.pack(
            side="left",
            fill="x",
            expand=True,
            padx=5
        )

        tk.Label(
            frame,
            text=title,
            bg=self.panel,
            fg=self.subtext,
            font=(
                "Segoe UI",
                8,
                "bold"
            )
        ).pack(
            anchor="w",
            padx=14,
            pady=(10, 1)
        )

        value_label = tk.Label(
            frame,
            text=value,
            bg=self.panel,
            fg=self.text,
            font=(
                "Segoe UI",
                18,
                "bold"
            )
        )

        value_label.pack(
            anchor="w",
            padx=14,
            pady=(0, 9)
        )

        return value_label

    # ========================================================
    # CREATE LIBRARY TAB
    # ========================================================

    def create_library_tab(self):

        top = tk.Frame(
            self.library_tab,
            bg=self.bg
        )

        top.pack(
            fill="x",
            padx=25,
            pady=(20, 10)
        )

        tk.Label(
            top,
            text="Account Library",
            bg=self.bg,
            fg=self.text,
            font=(
                "Segoe UI",
                23,
                "bold"
            )
        ).pack(
            anchor="w"
        )

        tk.Label(
            top,
            text=(
                "Accounts in this library are automatically "
                "excluded from future analyses."
            ),
            bg=self.bg,
            fg=self.subtext
        ).pack(
            anchor="w",
            pady=(3, 8)
        )

        # ----------------------------------------------------
        # Stats
        # ----------------------------------------------------

        stats = tk.Frame(
            self.library_tab,
            bg=self.bg
        )

        stats.pack(
            fill="x",
            padx=20,
            pady=7
        )

        self.library_stat_all = (
            self.library_stat_box(
                stats,
                "ALL ACCOUNTS",
                "0"
            )
        )

        self.library_stat_taken_down = (
            self.library_stat_box(
                stats,
                "TAKEN DOWN",
                "0"
            )
        )

        self.library_stat_online = (
            self.library_stat_box(
                stats,
                "STILL ONLINE",
                "0"
            )
        )

        # ----------------------------------------------------
        # Controls
        # ----------------------------------------------------

        controls = tk.Frame(
            self.library_tab,
            bg=self.bg
        )

        controls.pack(
            fill="x",
            padx=25,
            pady=7
        )

        self.app_button(
            controls,
            "🔄  Refresh",
            self.update_library,
            "#164e63",
            "#cffafe"
        ).pack(
            side="left",
            padx=(0, 6)
        )

        self.app_button(
            controls,
            "🌐  Open Channel",
            self.open_library_channel,
            "#334155",
            self.text
        ).pack(
            side="left",
            padx=6
        )

        self.app_button(
            controls,
            "🗑  Remove",
            self.remove_from_library,
            "#7f1d1d",
            "#fee2e2"
        ).pack(
            side="left",
            padx=6
        )

        self.app_button(
            controls,
            "📄  Open channels.txt",
            lambda:
                self._open_file(
                    Path("channels.txt")
                ),
            "#334155",
            self.text
        ).pack(
            side="right"
        )

        # ----------------------------------------------------
        # Table
        # ----------------------------------------------------

        frame = tk.Frame(
            self.library_tab,
            bg=self.bg
        )

        frame.pack(
            fill="both",
            expand=True,
            padx=25,
            pady=(5, 20)
        )

        cols = (
            "score",
            "name",
            "status",
            "flags",
            "url",
            "added"
        )

        self.library_tree = ttk.Treeview(
            frame,
            columns=cols,
            show="headings"
        )

        headings = {
            "score": "SCORE",
            "name": "ACCOUNT",
            "status": "STATUS",
            "flags": "FLAGS",
            "url": "CHANNEL URL",
            "added": "ADDED"
        }

        for column, heading in headings.items():

            self.library_tree.heading(
                column,
                text=heading
            )

        self.library_tree.column(
            "score",
            width=80,
            anchor="center"
        )

        self.library_tree.column(
            "name",
            width=220
        )

        self.library_tree.column(
            "status",
            width=150
        )

        self.library_tree.column(
            "flags",
            width=260
        )

        self.library_tree.column(
            "url",
            width=420
        )

        self.library_tree.column(
            "added",
            width=150
        )

        scroll = ttk.Scrollbar(
            frame,
            orient="vertical",
            command=self.library_tree.yview
        )

        self.library_tree.configure(
            yscrollcommand=scroll.set
        )

        self.library_tree.pack(
            side="left",
            fill="both",
            expand=True
        )

        scroll.pack(
            side="right",
            fill="y"
        )

        self.library_tree.bind(
            "<Double-1>",
            lambda event:
                self.open_library_channel()
        )

        self.update_library()

    # ========================================================
    # FILE OPEN
    # ========================================================

    def _open_file(
        self,
        path
    ):

        path.touch(
            exist_ok=True
        )

        try:

            os.startfile(
                str(path)
            )

        except AttributeError:

            webbrowser.open(
                path.resolve().as_uri()
            )

    # ========================================================
    # LIBRARY SELECTION
    # ========================================================

    def _library_selected(self):

        selection = (
            self.library_tree.selection()
        )

        if not selection:
            return None

        item = self.library_tree.item(
            selection[0]
        )

        return item.get(
            "values"
        )

    # ========================================================
    # UPDATE LIBRARY
    # ========================================================

    def update_library(self):

        if not hasattr(
            self,
            "library_tree"
        ):
            return

        data = self._library_data()

        urls = self._library_urls()

        # Add channel URLs from channels.txt.
        for url in urls:

            match = re.search(
                r"youtube\.com/channel/(UC[A-Za-z0-9_-]+)",
                url,
                re.I
            )

            if (
                match
                and match.group(1) not in data
            ):

                channel_id = match.group(1)

                data[channel_id] = {
                    "channel_id":
                        channel_id,
                    "url":
                        url,
                    "name":
                        "Unknown",
                    "score":
                        None,
                    "flags":
                        [],
                    "added":
                        None
                }

        for item in (
            self.library_tree.get_children()
        ):

            self.library_tree.delete(
                item
            )

        ids = [
            key
            for key, value in data.items()
            if (
                isinstance(
                    value,
                    dict
                )
                and value.get(
                    "channel_id"
                )
            )
        ]

        found = {}

        # ----------------------------------------------------
        # Check channels with API
        # ----------------------------------------------------

        if (
            ids
            and youtube_api_available()
        ):

            try:

                api = get_youtube_service()

                for i in range(
                    0,
                    len(ids),
                    50
                ):

                    batch = ids[
                        i:i + 50
                    ]

                    result = (
                        api.channels().list(
                            part="snippet,statistics",
                            id=",".join(batch)
                        ).execute()
                    )

                    found.update({
                        item["id"]: item
                        for item in result.get(
                            "items",
                            []
                        )
                    })

            except Exception:

                pass

        # ----------------------------------------------------
        # Statistics
        # ----------------------------------------------------

        total_accounts = len(
            data
        )

        online_accounts = 0
        taken_down_accounts = 0

        for channel_id, record in data.items():

            if not isinstance(
                record,
                dict
            ):
                continue

            if channel_id in found:

                online_accounts += 1

            else:

                taken_down_accounts += 1

        self.library_stat_all.config(
            text=str(
                total_accounts
            )
        )

        self.library_stat_taken_down.config(
            text=str(
                taken_down_accounts
            )
        )

        self.library_stat_online.config(
            text=str(
                online_accounts
            )
        )

        # ----------------------------------------------------
        # Populate
        # ----------------------------------------------------

        for channel_id, record in data.items():

            if not isinstance(
                record,
                dict
            ):
                continue

            item = found.get(
                channel_id
            )

            if item:

                name = (
                    item.get(
                        "snippet",
                        {}
                    ).get(
                        "title",
                        record.get(
                            "name",
                            "Unknown"
                        )
                    )
                )

                status = (
                    "🟢 Still Online"
                )

            else:

                name = record.get(
                    "name",
                    "Unknown"
                )

                if youtube_api_available():

                    status = (
                        "🔴 Taken Down"
                    )

                else:

                    status = (
                        "⚪ API Missing"
                    )

            flags = record.get(
                "flags",
                []
            )

            if isinstance(
                flags,
                list
            ):

                flags_text = ", ".join(
                    flags
                )

            else:

                flags_text = str(
                    flags
                )

            record["name"] = name

            self.library_tree.insert(
                "",
                "end",
                values=(
                    (
                        record.get(
                            "score"
                        )
                        if record.get(
                            "score"
                        ) is not None
                        else "-"
                    ),
                    name,
                    status,
                    flags_text or "-",
                    record.get(
                        "url",
                        "-"
                    ),
                    (
                        record.get(
                            "added",
                            ""
                        )
                        or ""
                    )[:16].replace(
                        "T",
                        " "
                    )
                )
            )

        self._save_library_data(
            data
        )

    # ========================================================
    # OPEN LIBRARY CHANNEL
    # ========================================================

    def open_library_channel(self):

        values = (
            self._library_selected()
        )

        if (
            values
            and len(values) > 4
        ):

            webbrowser.open(
                values[4]
            )

        else:

            messagebox.showinfo(
                "Library",
                "Please select an account first."
            )

    # ========================================================
    # REMOVE FROM LIBRARY
    # ========================================================

    def remove_from_library(self):

        values = (
            self._library_selected()
        )

        if not values:

            messagebox.showinfo(
                "Library",
                "Please select an account first."
            )

            return

        url = values[4]

        if not messagebox.askyesno(
            "Remove Account",
            (
                "Remove this account from the library?\n\n"
                "It may appear again in future analyses."
            )
        ):
            return

        urls = [
            current_url
            for current_url in self._library_urls()
            if current_url != url
        ]

        Path(
            "channels.txt"
        ).write_text(
            "\n".join(urls)
            + (
                "\n"
                if urls
                else ""
            ),
            encoding="utf-8"
        )

        data = self._library_data()

        for key, record in list(
            data.items()
        ):

            if (
                isinstance(
                    record,
                    dict
                )
                and record.get(
                    "url"
                ) == url
            ):

                del data[key]

        self._save_library_data(
            data
        )

        self.update_library()


# ============================================================
# MAIN
# ============================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = BotDetectorGUI(
        root
    )

    root.mainloop()